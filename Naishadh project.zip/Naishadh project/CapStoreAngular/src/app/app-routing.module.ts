import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddressComponent } from './address/address.component';
import { DisplayAddressComponent } from './display-address/display-address.component';

import { EditAddressComponent } from './edit-address/edit-address.component';

const routes: Routes = [
  { path: '', redirectTo: '/display', pathMatch: 'full' },
  { path: 'address', component: AddressComponent},
  { path: 'display', component: DisplayAddressComponent},
  { path: 'edit', component: EditAddressComponent},
  { path: '**', redirectTo: '/display', pathMatch: 'full'}


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
