import { Component, OnInit } from '@angular/core';
import { AddressModel } from '../model/address-model';
import { ActivatedRoute, Router } from '@angular/router';
import {filter} from 'rxjs/operators';
import { AddressService } from '../address.service';

@Component({
  selector: 'app-edit-address',
  templateUrl: './edit-address.component.html',
  styleUrls: ['./edit-address.component.css']
})
export class EditAddressComponent implements OnInit {
  editedAddress: AddressModel;

  paramIndex;
  constructor(private route: ActivatedRoute, private router: Router, private Service: AddressService) {
    this.editedAddress = new AddressModel();
   
  }

  ngOnInit() {
    if (window.location.search !== '') {

      this.route.queryParams.pipe(
      filter(params => params.id))
      .subscribe(params => {
      console.log(params.id);
      this.paramIndex = params.id;
      this.editedAddress = this.Service.getDetailsOf(this.paramIndex);
      });
    }
  }
  EditAddress() {
    this.Service.edit(this.paramIndex, this.editedAddress);
  }
}

