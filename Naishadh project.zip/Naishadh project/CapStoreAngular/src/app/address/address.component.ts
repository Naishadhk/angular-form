import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AddressModel } from '../model/address-model';
import { AddressService } from '../address.service';

@Component({
  selector: 'app-address',
  templateUrl: './address.component.html',
  styleUrls: ['./address.component.css']
})
export class AddressComponent implements OnInit {

 
  new: AddressModel;
  incorrectAddress1=false;
  incorrectAddress2=false;
  incorrectCity=false;
  incorrectState=false;
  

  constructor(private router: Router, private service:AddressService) {
      this.new = new AddressModel();
      this.new.address1='';
      this.new.address2='';
      this.new.city='';
      this.new.landmark='';
      this.new.state='';
      
     
   }

  ngOnInit() {
  }
  goBack() {
    this.router.navigate(['/display']);
  }
  addAddress() {
     
     if( this.new.address1.length<10 || this.new.address1.length>50 ) {
      this.incorrectAddress1=true;
    }
    else if(this.new.address2.length<10 || this.new.address2.length>50)
    {
      this.incorrectAddress1=false;
      this.incorrectAddress2=true;
    }
    else if(this.new.city.length<3 || this.new.city.length>20){
      this.incorrectAddress1=false;
      this.incorrectAddress2=false;
      this.incorrectCity=true;
    }
    else if(this.new.state.length<3 || this.new.state.length>20){
      this.incorrectAddress1=false;
      this.incorrectAddress2=false;
      this.incorrectCity=false;
      this.incorrectState=true;
    }
    else{
      this.service.add(this.new);
    }
    
  }

 
  }

  