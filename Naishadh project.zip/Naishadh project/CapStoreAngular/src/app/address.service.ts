import { AddressModel } from './model/address-model';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AddressService {
  Array: AddressModel[];
 

  constructor(private router: Router) {
    this.Array = [];
  }
  add(address: AddressModel) {

    this.Array.push(address);
    this.router.navigate(['/display']);
  }
  display() {
    return this.Array;
  }

  editAddress(index: number) {

    this.router.navigate(['/edit'], { queryParams: { id: index } });
  }
  getDetailsOf(index) {

    return this.Array[index];
  }
  edit(index: number, editedAddress:AddressModel ) {
    this.Array[index] = editedAddress;
    this.router.navigate(['/display']);
  }
  delete(index: number) {
    this.Array.splice(index, 1);
  }
  
}