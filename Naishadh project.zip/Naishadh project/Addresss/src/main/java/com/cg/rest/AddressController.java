/*
 * Author :-Naishadh Kalyanpur 173551
 * version:- 1.0.2
 */

package com.cg.rest;

import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entity.Address;
import com.cg.entity.Customer;
import com.cg.service.AddressService;

@RestController
public class AddressController {

	@Autowired
	private AddressService service;
	
	@PostMapping("/addaddress")
	public String saveAddress(@RequestParam("address1") String addLine1, @RequestParam("address2") String addLine2,
			@RequestParam("state") String state,@RequestParam("city") String city,@RequestParam("postalcode") Long postalCode,@RequestParam("customer") String customerFromAddress){
		Address a=new Address();
		a.setAddLine1(addLine1);
		a.setAddLine2(addLine2);
		a.setCity(city);
		a.setState(state);
		a.setPostalCode(postalCode);
		return "Address added";
	}
	
//	@GetMapping(name = "/findaddress", produces = "application/json")
//	public Address getAddress(@RequestParam("id") int id) {
//		Address a = service.get(id);
//		return a;
//	}
	
	@GetMapping(name = "/findaddress", produces = "application/json")
	public ResponseEntity<Address>  getAddress(@RequestParam("id") int id) {
		try {
			Address a = service.get(id);
			return new ResponseEntity<Address>(a, HttpStatus.OK);
		} catch (NoSuchElementException e) {
			return new ResponseEntity(e.getMessage(), HttpStatus.NOT_FOUND);
		}
	}
	
	@PutMapping(path ="/update/{id}", consumes = "application/json")
	public Address update(@PathVariable("id") int id, @RequestBody Address a) {
		return service.update(a, id);	
	
	}
	
	@DeleteMapping(path = "/delete/{id}")
	public String delete(@PathVariable("id") int id) {
		return service.deleteAddress(id);
	}
}
