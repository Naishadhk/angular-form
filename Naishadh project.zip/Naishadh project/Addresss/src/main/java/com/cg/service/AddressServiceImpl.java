/*
 * Author :-Naishadh Kalyanpur 173551
 * version:- 1.0.2
 */
package com.cg.service;

import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.entity.Address;
import com.cg.repo.AddressRepo;
@Service
@Transactional
public class AddressServiceImpl implements AddressService {

	@Autowired
	AddressRepo repo;
	
	@Override
	public void saveAddress(Address a) {
		repo.save(a);
	}

	@Override
	public Address get(int id) {
		try {
			return repo.findById(id).get();
		} catch (NoSuchElementException e) {
			throw new NoSuchElementException("Address not found");
		}
	}

	@Override
	public Address update(Address a, int id) {
		a.setId(id);
		repo.save(a);
		return a;
	}

	@Override
	public String deleteAddress(int id) {
		Address a=repo.findById(id).get();
		 repo.delete(a);
		 return "deleted successfully";
	}
	 
}
