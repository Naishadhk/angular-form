/*
 * Author :-Naishadh Kalyanpur 173551
 * version:- 1.0.2
 */

package com.cg.repo;

import org.springframework.data.repository.CrudRepository;

import com.cg.entity.Address;

public interface AddressRepo extends CrudRepository<Address, Integer> {

}
