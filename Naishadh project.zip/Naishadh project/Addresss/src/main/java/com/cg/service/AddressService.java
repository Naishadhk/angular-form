/*
 * Author :-Naishadh Kalyanpur 173551
 * version:- 1.0.2
 */

package com.cg.service;

import com.cg.entity.Address;

public interface AddressService {
	void saveAddress(Address a);

	Address get(int id);

	Address update(Address a, int id);
	
	public String deleteAddress(int id);
}
