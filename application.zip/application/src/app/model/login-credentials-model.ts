export class LoginCredentialsModel {
    email: String;
    password: String;
    name:String;
}
